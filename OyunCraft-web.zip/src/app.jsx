import React from "react";
import OyunTabs from "./components/OyunTabs";

function App() {
  return (
    <div className="bg-gray-900 text-white min-h-screen p-4">
      <h1 className="text-3xl font-bold mb-6">🎮 Oyuncraft</h1>
      <OyunTabs />
    </div>
  );
}

export default App;
